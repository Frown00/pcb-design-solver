type Length = number;
