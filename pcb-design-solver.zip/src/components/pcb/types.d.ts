type Point = { x: number, y: number };
type Connection = [Point, Point];