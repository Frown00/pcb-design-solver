const BOX_SIZE = 20;

export {
  BOX_SIZE
}